---
name: FitBMI Pro
colors:
  surface: '#111414'
  surface-dim: '#111414'
  surface-bright: '#363a3a'
  surface-container-lowest: '#0b0f0f'
  surface-container-low: '#191c1d'
  surface-container: '#1d2021'
  surface-container-high: '#272b2b'
  surface-container-highest: '#323536'
  on-surface: '#e1e3e3'
  on-surface-variant: '#bec8c9'
  inverse-surface: '#e1e3e3'
  inverse-on-surface: '#2e3131'
  outline: '#889393'
  outline-variant: '#3f4949'
  surface-tint: '#8ad3d7'
  primary: '#8ad3d7'
  on-primary: '#003739'
  primary-container: '#006064'
  on-primary-container: '#8fd8dc'
  inverse-primary: '#14696d'
  secondary: '#a2cfcb'
  on-secondary: '#053734'
  secondary-container: '#224e4b'
  on-secondary-container: '#91bdba'
  tertiary: '#66d9cc'
  on-tertiary: '#003732'
  tertiary-container: '#006159'
  on-tertiary-container: '#6bded1'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#a6eff3'
  primary-fixed-dim: '#8ad3d7'
  on-primary-fixed: '#002021'
  on-primary-fixed-variant: '#004f53'
  secondary-fixed: '#beebe7'
  secondary-fixed-dim: '#a2cfcb'
  on-secondary-fixed: '#00201e'
  on-secondary-fixed-variant: '#224e4b'
  tertiary-fixed: '#84f5e8'
  tertiary-fixed-dim: '#66d9cc'
  on-tertiary-fixed: '#00201d'
  on-tertiary-fixed-variant: '#005049'
  background: '#111414'
  on-background: '#e1e3e3'
  surface-variant: '#323536'
typography:
  display-lg:
    fontFamily: Lexend
    fontSize: 57px
    fontWeight: '700'
    lineHeight: 64px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Lexend
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-md:
    fontFamily: Lexend
    fontSize: 28px
    fontWeight: '500'
    lineHeight: 36px
  title-lg:
    fontFamily: Inter
    fontSize: 22px
    fontWeight: '500'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0.5px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0.25px
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.1px
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.5px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 8px
  container-padding: 24px
  gutter: 16px
  card-gap: 12px
  section-margin: 32px
---

## Brand & Style

This design system establishes a premium, clinical-yet-approachable atmosphere for a high-end health and fitness experience. The brand personality is authoritative, precise, and motivating, aiming to evoke a sense of calm control over one's physical well-being.

The aesthetic blends the structural logic of **Material Design 3** with the depth and sophistication of **Glassmorphism**. By utilizing translucent layers for high-level containers, the UI maintains a sense of lightness even when displaying complex health data. The design is optimized for high-performance tracking, ensuring that every interaction feels fluid and intentional. 

For the international market, the system is architected to be bi-directional, ensuring that the visual weight and narrative flow translate perfectly between LTR (English) and RTL (Arabic) contexts without losing the premium "glassy" essence.

## Colors

The palette is rooted in medical professionalism and natural energy. **Deep Teal** serves as the primary anchor, providing a sophisticated, stable foundation that inspires trust. **Energizing Mint** acts as the high-contrast accent, used sparingly for calls to action, progress indicators, and "active" states to provide a burst of visual vitality.

The design system supports a dual-mode approach:
- **Light Mode:** Uses high-transparency white surfaces (70-80% opacity) over subtle teal-tinted background gradients to achieve the glass effect.
- **Dark Mode:** Replaces pure blacks with a deep "Midnight Teal" (#001F20) to maintain brand cohesion. Glass elements utilize dark translucent overlays with a 1px inner stroke to define boundaries against the dark background.

Interactive charts use a monochromatic scale of the primary teal for data series, with the mint accent reserved for highlighting the current user goal or peak performance metrics.

## Typography

This design system utilizes **Lexend** for headlines to leverage its rhythmic, athletic, and highly legible qualities—perfect for a fitness context. For body copy and technical data, **Inter** provides a neutral, systematic clarity that excels in both English and its Arabic equivalent (ensuring X-height harmony).

In RTL layouts, font weights remain consistent, but letter spacing is reset to 0 to accommodate the cursive nature of the Arabic script. Numeric data in charts and BMI readouts should utilize tabular figures to ensure alignment in history lists.

## Layout & Spacing

The layout follows a **fluid grid** model based on an 8px square rhythm, providing a logical scale for all UI elements. 

- **Margins:** A standard 24px side margin is used for mobile views to allow the glassmorphism background blurs to be visible at the screen edges.
- **Grids:** A 4-column grid for mobile and a 12-column grid for tablet/desktop. 
- **RTL Handling:** The grid system is mirrored for Arabic. Padding and margins labeled as `start` and `end` are used globally to ensure seamless flipping between LTR and RTL without manual overrides.
- **Information Density:** Lists and history logs use a "Comfortable" density with 16px vertical padding to maintain a premium, uncluttered feel.

## Elevation & Depth

Hierarchy is established through **Backdrop Filter Blurs** and **Tonal Layering** rather than traditional heavy shadows.

- **Level 0 (Background):** Solid brand surface or deep gradient.
- **Level 1 (Cards/Lists):** Glassmorphism effect. In light mode, `rgba(255, 255, 255, 0.7)` with a 20px backdrop blur. In dark mode, `rgba(0, 31, 32, 0.6)` with a 24px blur.
- **Level 2 (Active States/Floating Buttons):** A subtle, diffused ambient shadow (color-tinted with Deep Teal) is added to indicate interactivity.
- **Outlines:** All glass cards feature a 1px semi-transparent border (the "shine edge") to ensure separation between stacked elements.

## Shapes

The shape language is **Rounded**, following Material 3's modern evolution. 

- **Standard Cards:** 1rem (16px) corner radius.
- **Buttons & Chips:** Fully pill-shaped (rounded-full) to provide a soft, tactile contrast to the geometric charts.
- **Input Fields:** 0.5rem (8px) corner radius to maintain a professional, slightly more structured appearance for data entry.

These rounded forms help soften the "clinical" nature of health tracking, making the app feel more like a lifestyle companion and less like a medical tool.

## Components

### Buttons & Interaction
- **Primary Button:** Solid Deep Teal with white text for LTR, or Mint with Teal text for high-importance Dark Mode actions. Pill-shaped.
- **Secondary/Ghost:** Transparent background with a Teal stroke or glass effect.

### Glass Cards
- **Health Metrics:** Used for BMI and weight summaries. Must include a 1px top-left "light source" highlight to enhance the glass effect.
- **Interactive Charts:** Line and bar charts are housed within glass containers. Grid lines should be faint (10% opacity) to keep the focus on the data trend.

### Specialized Health Elements
- **Water Tracker:** A custom visualization using a vertical or circular progress fill in Energizing Mint, featuring a subtle "liquid" wave animation at the top of the fill level.
- **History Tracking Lists:** Clean, edge-to-edge list items with 1px teal-tinted dividers. In RTL, icons and trailing metadata (e.g., timestamps) must flip positions.
- **Selection Controls:** Checkboxes and radio buttons use the Energizing Mint for the "Checked" state to provide clear visual feedback against the Teal background.

### Chart Tooltips
- Floating glass overlays that appear on tap, displaying precise data points with high-contrast Inter typography.